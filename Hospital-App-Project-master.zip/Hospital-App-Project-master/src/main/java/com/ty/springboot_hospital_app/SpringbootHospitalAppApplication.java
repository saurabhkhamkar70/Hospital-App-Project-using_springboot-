package com.ty.springboot_hospital_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootHospitalAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootHospitalAppApplication.class, args);
	}

}
